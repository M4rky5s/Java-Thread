# Daugiagijis (threads) Duomenų Įkėlimas ir duomenų manipuliavimas naudojant Stream API
